close all; clear;

addpath(genpath('matlab_tools'))


yt_ugc_yt_features = readtable(fullfile('yt_ugc_features', ...
    'original_videos_dataset_selection_features.csv'));
yt_ugc_yt_metrics  = readtable(fullfile('yt_ugc_features', ...
    'original_videos_metrics.csv'));

yt_ugc_our_feats = readtable(fullfile('results/yt_ugc_new',...
    'yt_ugc_new_output_stats.csv'));
yt_ugc_our_full_names = readtable(fullfile('results/yt_ugc_new',...
    'yt_ugc_new_clean_vnames.csv'));

yt_ugc_our_feats_old = readtable(fullfile('results/yt_ugc',...
    'yt_ugc_output_stats.csv'));
yt_ugc_our_full_names_old = readtable(fullfile('results/yt_ugc',...
    'yt_ugc_clean_vnames.csv'));

yt_features = table2array(yt_ugc_yt_features(:,4:7));
yt_metrics = table2cell(yt_ugc_yt_metrics(:,2:4));

our_feats = table2array(yt_ugc_our_feats(:,2:13));
full_names = table2cell(yt_ugc_our_full_names(:,:));

our_feats_matched = zeros(size(yt_features,1), size(our_feats,2));


for i = 1:length(full_names(:,1))
    str_split = split(full_names{i,1}, '/');
    filename = split(str_split{end}, '.');
     if any(strcmp(yt_ugc_yt_features.FILENAME, filename{1}))
        idx = find(strcmp(yt_ugc_yt_features.FILENAME, filename{1}));
         our_feats_matched(idx,:) = our_feats(i,:);
     end
end

our_feats_matched = our_feats_matched(any(our_feats_matched,2),:);
plcc = corr(yt_features, our_feats_matched, 'Type', 'Pearson', 'rows', 'complete');
klcc = corr(yt_features, our_feats_matched, 'Type', 'Kendall', 'rows', 'complete');
srcc = corr(yt_features, our_feats_matched, 'Type', 'Spearman', 'rows', 'complete');


% 
[coeff,pca_feats,latent,tsquared,explained,mu] = pca(our_feats_matched);

%[coeff,score,latent,tsquared,explained] = pca(yt_features);

corr(pca_feats(:,1:6), yt_features, 'Type', 'Pearson', 'rows', 'complete');

nans = sum(isnan(our_feats_matched),2) > 0;

[A, B, r, U, V, STATS] = canoncorr(our_feats_matched(~nans, 1:2:11), yt_features(~nans,:));

[A_pca, B_pca, r_pca, U_pca, V_pca, STATS_pca] = canoncorr(pca_feats(~nans,1:6), ...
    yt_features(~nans,:));
