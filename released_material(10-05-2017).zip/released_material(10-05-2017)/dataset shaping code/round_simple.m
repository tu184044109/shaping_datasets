function out=round_simple(x,n)

x=x*10^n;
x=round(x);
out=x/10^n;

end



